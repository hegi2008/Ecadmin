package com.yinhai.ec.base.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
* @package com.yinhai.ec.base.controller
* <p>Title: SSOReceiveController.java</p>
* <p>Description: 用于接收sso登陆后,传递过来的用户信息,并且跳转页面</p>
* @author 刘惠涛
* @date 2016年9月12日 下午3:13:03
* @version 1.0
 */
@Controller
public class SSOReceiveController extends BaseController{
	@RequestMapping("/ssoreceive")
	public Object receive(HttpServletRequest request) {
		String username = request.getRemoteUser();
		request.getSession().setAttribute("username", username);
		return "redirect:/swagger/index.html";
	}
}
